package com.gayani;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

public class Seeprofile extends AppCompatActivity {
    TextView tv16,tv17,tv18,tv19,tv20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seeprofile);
        tv16 = (TextView)findViewById(R.id.tv16);
        tv17 = (TextView)findViewById(R.id.tv17);
        tv18 = (TextView)findViewById(R.id.tv18);
        tv19 = (TextView)findViewById(R.id.tv19);
        tv20 = (TextView)findViewById(R.id.tv20);

        MyHelper hlp = new MyHelper(this);
        SQLiteDatabase ddb = hlp.getReadableDatabase();
        Intent out = getIntent();
        String indxs = out.getStringExtra("index");
        //String passwod = out.getStringExtra("pass");

        Cursor v = ddb.rawQuery("select name, index_no , email, mobile, GPA From students Where index_no=?",new String[]{indxs},null);
        v.moveToFirst();
        String name = v.getString(0);
        String index = v.getString(1);
        String email = v.getString(2);
        String mobile = v.getString(3);
        String GPA = v.getString(4);
        tv16.setText(name);
        tv17.setText(index);
        tv18.setText(email);
        tv19.setText(mobile);
        tv20.setText(GPA);
    }
}
