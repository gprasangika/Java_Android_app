package com.gayani;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    EditText name, index, Email, Mbile, cgpa, passwd, repasswd;
    Button btx;
    TextView tv8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = (EditText) findViewById(R.id.et8);
        index = (EditText) findViewById(R.id.et9);
        Email = (EditText) findViewById(R.id.ed3);
        Mbile = (EditText) findViewById(R.id.ed4);
        cgpa = (EditText) findViewById(R.id.ed5);
        passwd = (EditText) findViewById(R.id.ed6);
        repasswd = (EditText) findViewById(R.id.ed7);
        tv8 = (TextView) findViewById(R.id.tv8);
        btx = (Button) findViewById(R.id.btn1);
        MyHelper dbhelper = new MyHelper(this);
        final SQLiteDatabase db = dbhelper.getWritableDatabase();
        final SQLiteDatabase dbase = dbhelper.getReadableDatabase();
        btx.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                int count = 0;
                int h = 0;
                boolean x = false;

                AlertDialog.Builder Build = new AlertDialog.Builder(MainActivity.this);
                String nm = name.getText().toString();
                String indx = index.getText().toString();
                String email = Email.getText().toString();
                String mobile = Mbile.getText().toString();
                String cgp = cgpa.getText().toString();
                String passw = passwd.getText().toString();
                String repass = repasswd.getText().toString();
                if (nm.equals("")) {
                    count++;
                }
                if (indx.equals("")) {
                    count++;
                }
                if (email.equals("")) {
                    count++;
                }
                if (mobile.equals("")) {
                    count++;
                }
                if (cgp.equals("")) {
                    count++;
                }
                if (passw.equals("")) {
                    count++;
                }
                if (repass.equals("")) {
                    count++;
                }
                for (int p = 0; p < email.length(); p++) {
                    if ((email.charAt(p) == '.') && (email.charAt(p + 1) == '.')) {
                        x = false;
                        p = email.length() + 1;
                    } else {
                        x = true;
                    }
                }

                if (count == 0) {
                    if ((Pattern.matches("^[a-z0-9][a-z0-9\\-_.]*[a-z0-9]\\@[a-z][a-z0-9\\-]*[a-z]\\.[a-z][a-z]+", email)) && (x == true)) {
                        h++;

                    } else {
                        Build.setMessage("Invalid Email!").setPositiveButton("OK", null).setNegativeButton("Cancel", null);
                        AlertDialog alert = Build.create();
                        alert.show();
                    }
                    if (mobile.length() == 10) {
                            h++;
                    } else {
                        Build.setMessage("Invalid Mobile No!").setPositiveButton("OK", null).setNegativeButton("Cancel", null);
                        AlertDialog alert = Build.create();
                        alert.show();

                    }
                    if ((indx.length() == 7) && Pattern.matches("^17[0-9]+[A-Z]$", indx)) {
                        h++;
                    } else {
                        Build.setMessage("Invalid Index No!").setPositiveButton("OK", null).setNegativeButton("Cancel", null);
                        AlertDialog alert = Build.create();
                        alert.show();
                    }
                    if (passw.equals(repass)) {
                        h++;
                    } else {
                        Build.setMessage("Password and Re-enter Password are not matching!").setPositiveButton("OK", null).setNegativeButton("Cancel", null);
                        AlertDialog alert = Build.create();
                        alert.show();
                    }
                }
                else
                    {
                    Build.setMessage("All fields must be filled!").setPositiveButton("OK", null).setNegativeButton("Cancel", null);
                    AlertDialog alert = Build.create();
                    alert.show();
                }
                if (h == 4) {
                    Cursor cr = dbase.rawQuery("Select * From students Where  index_no=?",new String[]{indx},null);


                    if (!cr.moveToFirst()) {

                        ContentValues values = new ContentValues();
                        values.put("name", nm);
                        values.put("index_no", indx);
                        values.put("email", email);
                        values.put("mobile", mobile);
                        values.put("GPA", cgp);
                        values.put("password", passw);
                        Long row = db.insert("students", null, values);
                        if (row != 0) {
                            Build.setMessage("Data Inserted!").setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent i = new Intent(getApplicationContext(), Login.class);
                                    startActivity(i);
                                }
                            }).setNegativeButton("Cancel", null).setCancelable(false);
                            AlertDialog alert = Build.create();
                            alert.show();
                        } else {
                            Build.setMessage("Data Could not be inserted!").setPositiveButton("OK", null).setNegativeButton("Cancel", null).setCancelable(false);
                            AlertDialog alert = Build.create();
                            alert.show();
                        }
                    }
                    else
                    {

                        Build.setMessage("You have been already registered!").setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent inte = new Intent(MainActivity.this, Login.class);
                                startActivity(inte);
                            }
                        }).setCancelable(false);
                        AlertDialog alert = Build.create();
                        alert.show();
                    }

                }
            }

        });

    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder al1 = new AlertDialog.Builder(this);
        al1.setTitle("Realy want to exit?").setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MainActivity.super.onBackPressed();
            }
        }).setNegativeButton("Cancel", null).setCancelable(false);
        AlertDialog alert = al1.create();
        alert.show();
    }
}
